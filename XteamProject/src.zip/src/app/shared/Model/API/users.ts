export class Users {
  userId?:number;
  username?:string;
  email?:string;
  password?:string;
  isAdmin?:boolean;
}
