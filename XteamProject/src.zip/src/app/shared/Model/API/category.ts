import { ProductAPI } from './product-api';
export class Category {
  categoryId?:number;
  categoryName?:string;
  products?:ProductAPI[];
}
