import { Category } from 'src/app/shared/Model/API/category';
import { Images } from './images';
export class ProductAPI {

  productId?:number;
  categoryId?:number;
  productName?:string;
  price?:string;
  actualPrice?:string;
  quantity?:string;
  description?:string;
  color?:string;
  counter?:number;
  category?:Category
  // {
  //   categoryId?:Number,
  //   categoryName?:String,
  // }
  images?:Images[]
  // {
  //   imageID?:Number,
  //   path?:String,
  //   productID?:Number,
  // }
}
