export class Images {
  imageID?:Number;
    path?:String;
    productID?:Number;
}
