import { OnScrollDirective } from './on-scroll.directive';

describe('OnScrollDirective', () => {
  it('should create an instance', () => {
    const directive = new OnScrollDirective();
    expect(directive).toBeTruthy();
  });
});
