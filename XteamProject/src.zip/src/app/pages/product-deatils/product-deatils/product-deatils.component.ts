import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CartService } from 'src/app/shared/services/cart.service';

@Component({
  selector: 'app-product-deatils',
  templateUrl: './product-deatils.component.html',
  styleUrls: ['./product-deatils.component.css'],
})
export class ProductDeatilsComponent implements OnInit {
  idProduct: number;
  productName: string;
  price: number;
  Category: string;
  Discription: string;
  itemCount: number;
  imgPath: string;
  itemNumber: number;

  constructor(
    private cartService: CartService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.idProduct = Number(this.route.snapshot.paramMap.get('Id'));
    this.productName = this.route.snapshot.queryParamMap.get('Name');
    this.price = Number(this.route.snapshot.queryParamMap.get('price'));
    this.Discription = this.route.snapshot.queryParamMap.get('Dis');
    this.Category = this.route.snapshot.queryParamMap.get('Category');
    this.imgPath = this.route.snapshot.queryParamMap.get('img');

    this.itemCount = this.itemCount ? this.itemCount : 1;
    this.itemNumber = this.itemCount;
  }

  addToCart() {
    debugger;
    this.itemCount = this.itemNumber;
    const obj = {
      Id: this.idProduct,
      productName: this.productName,
      price: this.price,
      Category: this.Category,
      Discription: this.Discription,
      itemCount: this.itemCount,
      imgPath: this.imgPath,
    };

    //this.cartService.addItemToCart(obj);
  }

  pluseMin(op: string) {
    switch (op) {
      case '-':
        this.itemNumber -= 1;
        break;
      case '+':
        this.itemNumber += 1;
        break;
    }
    if (this.itemNumber < 0) {
      this.itemNumber = 1;
    }
  }
}
